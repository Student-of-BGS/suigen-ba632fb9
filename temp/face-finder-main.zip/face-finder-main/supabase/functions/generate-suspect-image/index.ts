import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { case_id } = await req.json();
    if (!case_id) throw new Error("case_id is required");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
    );

    // Get user ID from auth
    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) throw new Error("Unauthorized");

    // Check if there's already a pending/processing request for this case
    const { data: existingQueue } = await supabaseClient
      .from("image_generation_queue")
      .select("*")
      .eq("case_id", case_id)
      .in("status", ["pending", "processing"])
      .maybeSingle();

    if (existingQueue) {
      return new Response(
        JSON.stringify({ 
          error: "Image generation already in progress for this case. Please wait.",
          queueId: existingQueue.id 
        }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get next available processing slot
    const { data: nextSlot } = await supabaseClient.rpc("get_next_processing_slot");
    const now = new Date();
    const slotTime = new Date(nextSlot);
    
    if (slotTime > now) {
      const waitSeconds = Math.ceil((slotTime.getTime() - now.getTime()) / 1000);
      return new Response(
        JSON.stringify({ 
          error: `Rate limit protection: Please wait ${waitSeconds} seconds before trying again.`,
          retryAfter: waitSeconds 
        }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": waitSeconds.toString()
          } 
        }
      );
    }

    // Create queue entry
    const { data: queueEntry, error: queueError } = await supabaseClient
      .from("image_generation_queue")
      .insert({
        case_id,
        user_id: user.id,
        status: "processing",
        started_at: new Date().toISOString()
      })
      .select()
      .single();

    if (queueError) throw queueError;

    const { data: attributes, error: attrError } = await supabaseClient
      .from("suspect_physical_attributes")
      .select("*")
      .eq("case_id", case_id)
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (attrError) throw attrError;

    const basePrompt = `Realistic digital forensic composite portrait of a single human suspect.

ROLE:
You are a digital forensic sketch generator. Based on structured physical descriptions, you must produce a realistic police-style digital sketch of a suspect.

OUTPUT STYLE GUIDELINES:
- Crime investigation style sketch / digital composite rendering
- Realistic human face based on real-world facial proportions
- Neutral facial expression unless otherwise specified
- High clarity, well-defined facial structure, accurate skin tone and texture
- Bust portrait, chest and head only, subject centered in frame
- Camera: front-facing, straight-on view, eye level
- Lighting: soft, even studio lighting, no dramatic shadows
- Background: plain, clean (white, light grey, or police-ID backdrop)
- No text, no logos, no watermarks, no frames, no labels
- No extra limbs, no multiple faces, no cropped head, no artistic borders
- Avoid stylization: NO anime, cartoon, abstract, or fantasy elements

INSTRUCTIONS:
- Interpret the description as precisely as possible.
- If details are missing, choose the most neutral/default appearance.
- DO NOT invent unrealistic features or distort identity-like elements.
- Produce EXACTLY ONE suspect image per request.

SUSPECT DESCRIPTION (use every field that is specified):
Gender: ${attributes.gender || "Not specified"}
Age: ${attributes.age || "Not specified"} years old
Ethnicity: ${attributes.ethnicity || "Not specified"}
Skin Tone: ${attributes.skin_tone || "Not specified"}
Body Type: ${attributes.body_type || "Not specified"}
Height: ${attributes.height_feet || "Not specified"} feet

FACIAL FEATURES:
Head Shape: ${attributes.head_shape || "Not specified"}
Hair Length: ${attributes.hair_length || "Not specified"}
Hair Style: ${attributes.hair_style || "Not specified"}
Hair Texture: ${attributes.hair_texture || "Not specified"}
Hairline Shape: ${attributes.hairline_shape || "Not specified"}

EYES:
Eye Color: ${attributes.eye_color || "Not specified"}
Eye Shape: ${attributes.eye_shape || "Not specified"}
Eye Size/Spacing: ${attributes.eye_size_spacing || "Not specified"}
Eyebrow Type: ${attributes.eyebrow_type || "Not specified"}
Eyelid Type: ${attributes.eyelid_type || "Not specified"}
Eyelashes: ${attributes.eyelashes || "Not specified"}
Eye Bags/Wrinkles: ${attributes.eye_bags_wrinkles || "Not specified"}

NOSE:
Nose Shape: ${attributes.nose_shape || "Not specified"}
Bridge Height: ${attributes.bridge_height || "Not specified"}
Nose Tip Shape: ${attributes.nose_tip_shape || "Not specified"}
Nostril Width: ${attributes.nostril_width || "Not specified"}

MOUTH:
Lip Shape: ${attributes.lip_shape || "Not specified"}
Lip Thickness: ${attributes.lip_thickness || "Not specified"}
Mouth Width: ${attributes.mouth_width || "Not specified"}
Smile Type: ${attributes.smile_type || "Not specified"}

FACIAL STRUCTURE:
Chin Shape: ${attributes.chin_shape || "Not specified"}

FACIAL HAIR:
Facial Hair Type: ${attributes.facial_hair_type || "Not specified"}
Beard Color: ${attributes.beard_color || "Not specified"}

EARS:
Ear Shape: ${attributes.ear_shape || "Not specified"}
Ear Size: ${attributes.ear_size || "Not specified"}
Ear Lobes: ${attributes.ear_lobes || "Not specified"}
Helix/Antihelix: ${attributes.helix_antihelix || "Not specified"}

SKIN:
Other Skin Features: ${attributes.other_skin_features || "Not specified"}

ACCESSORIES:
Accessories: ${attributes.accessories || "Not specified"}

FINAL VISUAL SUMMARY (most important):
Create a front-facing, chest-and-head portrait of a ${attributes.gender || "adult"} approximately ${attributes.age || "adult"} years old, of ${attributes.ethnicity || "unspecified"} ethnicity, about ${attributes.height_feet || "average"} feet tall, with ${attributes.body_type || "average"} build, ${attributes.skin_tone || "natural"} skin tone, ${attributes.hair_length || "medium"} ${attributes.hair_style || "simple"} ${attributes.hair_texture || "straight"} hair, and ${attributes.eye_color || "natural-colored"} eyes. Neutral expression, no smile unless specified, plain light background, realistic forensic composite style, no text or decorative elements.`;

    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!lovableApiKey) throw new Error("LOVABLE_API_KEY not configured");

    // Generate 4 different variations
    const variations = [
      "Generate this portrait with slightly different lighting angles.",
      "Generate this portrait with a subtle variation in expression.",
      "Generate this portrait from a very slightly different angle.",
      "Generate this portrait with alternative interpretation of facial features."
    ];

    const imagePromises = variations.map(async (variation, index) => {
      const prompt = `${basePrompt}\n\nVariation ${index + 1}: ${variation}`;
      
      console.log(`Generating image ${index + 1}/4...`);
      
      const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${lovableApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash-image-preview",
          messages: [
            {
              role: "user",
              content: prompt
            }
          ],
          modalities: ["image", "text"]
        }),
      });

      if (!aiResponse.ok) {
        const errorText = await aiResponse.text();
        console.error(`Lovable AI Error for image ${index + 1} (${aiResponse.status}):`, errorText);
        
        if (aiResponse.status === 429) {
          throw new Error("Rate limits exceeded, please try again later.");
        }
        if (aiResponse.status === 402) {
          throw new Error("Payment required, please add funds to your Lovable AI workspace.");
        }
        
        throw new Error(`AI gateway error: ${aiResponse.status}`);
      }

      const aiResult = await aiResponse.json();
      console.log(`Image ${index + 1} response received`);
      
      const imageUrl = aiResult.choices?.[0]?.message?.images?.[0]?.image_url?.url;
      if (!imageUrl) {
        console.error(`No image data found for image ${index + 1}. Full response:`, JSON.stringify(aiResult, null, 2));
        throw new Error(`No image data in response for variation ${index + 1}`);
      }

      return imageUrl;
    });

    // Wait for all 4 images to generate
    const images = await Promise.all(imagePromises);
    console.log(`Successfully generated ${images.length} images`);

    // Update queue entry as completed
    await supabaseClient
      .from("image_generation_queue")
      .update({
        status: "completed",
        completed_at: new Date().toISOString()
      })
      .eq("id", queueEntry.id);

    return new Response(
      JSON.stringify({ images }), 
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in generate-suspect-image:", error);
    
    // Try to update queue status to failed if we have a queue entry
    try {
      const { case_id } = await req.json().catch(() => ({}));
      if (case_id) {
        const supabaseClient = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_ANON_KEY") ?? "",
          { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
        );
        
        await supabaseClient
          .from("image_generation_queue")
          .update({
            status: "failed",
            completed_at: new Date().toISOString(),
            error_message: error?.message || "Unknown error"
          })
          .eq("case_id", case_id)
          .eq("status", "processing");
      }
    } catch (updateError) {
      console.error("Failed to update queue status:", updateError);
    }
    
    return new Response(JSON.stringify({ error: error?.message || "Error" }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 });
  }
});
